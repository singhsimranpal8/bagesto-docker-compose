php bagisto/artisan  bagisto:install
chmod -R 755 /var/www/html/bagisto && chmod 777 -R /var/www/html/bagisto/storage
